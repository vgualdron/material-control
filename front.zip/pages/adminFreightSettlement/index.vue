<template>
  <b-container fluid>
    <table-list />
    <modal-form />
  </b-container>
</template>

<script>
import TableList from '@/components/adminFreightSettlement/TableList.vue';
import ModalForm from '@/components/adminFreightSettlement/ModalForm.vue';
export default {
  name: 'adminFreightSettlement',
  layout: 'menu',
  components: {
    TableList,
    ModalForm
  },
  data () {
    return {
    };
  },
  computed: {
  },
  mounted () {
  },
  methods: {
  }
};
</script>
