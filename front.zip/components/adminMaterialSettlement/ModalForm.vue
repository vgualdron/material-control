<template>
  <b-modal
    v-model="showModalForm"
    :id="id"
    no-close-on-backdrop
    no-close-on-esc
    size="xl"
    @hide="resetInfoModal">
    <template #modal-header>
      <h5>{{ title }}</h5>
      <b-icon-x @click="resetInfoModal()" class="icon-close" font-scale="2"></b-icon-x>
    </template>
    <b-form
      @submit="handleForm">
      <b-form-group class="mb-1">
        <b-form-row>
          <b-col md="4">
            <label for="feedback-consecutive">Consecutivo</label>
            <b-form-input
              id="feedback-consecutive"
              v-model="consecutive"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-date">Fecha</label>
            <b-form-input
              id="feedback-date"
              v-model="date"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-third">Tercero</label>
            <b-form-input
              id="feedback-third"
              v-model="third"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
        </b-form-row>
        <b-form-row>
          <b-col md="4">
            <label for="feedback-amount">Cantidad</label>
            <b-form-input
              id="feedback-amount"
              v-model="subtotalAmount"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-retention-percentage">Porcentaje Retencion</label>
            <b-form-input
              id="feedback-retention-precentage"
              v-model="retentionsPercentage"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-retention">Retención</label>
            <b-form-input
              id="feedback-retention"
              v-model="retentions"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
        </b-form-row>
        <b-form-row>
          <b-col>
            <label for="feedback-base-royalties">Base Regalías</label>
            <b-form-input
              id="feedback-base-royalties"
              v-model="baseRoyalties"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col>
            <label for="feedback-royalties">Regalías</label>
            <b-form-input
              id="feedback-royalties"
              v-model="royalties"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-subtotal">Subtotal</label>
            <b-form-input
              id="feedback-subtotal"
              v-model="subtotalSettlement"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
        </b-form-row>
        <b-form-row>
          <b-col md="4">
            <label for="feedback-total">Total</label>
            <b-form-input
              id="feedback-total"
              v-model="totalSettle"
              type="text"
              :disabled="true"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-invoice">Factura</label>
            <b-form-input
              id="feedback-invoice"
              v-model="invoice"
              type="text"
              required>
            </b-form-input>
          </b-col>
          <b-col md="4">
            <label for="feedback-invoice-date">Fecha Factura</label>
            <b-form-datepicker
              id="feedback-invoice-date"
              v-model="invoiceDate"
              type="text"
              required>
            </b-form-datepicker>
          </b-col>
        </b-form-row>
        <b-form-row>
          <b-col md="4">
            <label for="feedback-internal-document">Documento Interno</label>
            <b-form-input
              id="feedback-internal-document"
              v-model="internalDocument"
              type="text"
              required>
            </b-form-input>
          </b-col>
        </b-form-row>
        <b-form-group>
          <label for="feedbackobservation">Observaciones</label>
          <b-form-textarea
            id="feedbackobservation"
            v-model="observation"
            maxlength="200"
            no-resize
            rows="3"
            :disabled="true"
            >
          </b-form-textarea>
        </b-form-group>
      </b-form-group>
      <b-button
        id="button-submit"
        type="submit"
        href="#"
        variant="primary"
        class="mt-3 form-control"
        :disabled="false"
        @click="handleForm">
        {{ textBtnSubmit }}
      </b-button>
      <b-button
        id="button-submit"
        type="submit"
        href="#"
        variant="primary"
        class="mt-3 form-control"
        :disabled="false"
        @click="generateReport">
        Imprimir
      </b-button>
    </b-form>
    <template #modal-footer>
      <div class="w-100">
        <b-button
          variant="secondary"
          size="sm"
          class="float-right"
          @click="resetInfoModal()">
          Cancelar
        </b-button>
      </div>
    </template>
    <template>
      <b-table
        class="mt-4"
        :striped="true"
        :bordered="true"
        :hover="true"
        :fixed="true"
        :items="items"
        :fields="fields"
        stacked="md"
        show-empty
        small
      >
        <template v-slot:cell(material_settle_receipt_weight)="row">
          <b-form-checkbox
            :checked="row.item.material_settle_receipt_weight=== '1' ? true : false"
            :disabled="true"
          />
        </template>
      </b-table>
    </template>
  </b-modal>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import { typesAdminMaterialSettlement as types } from '@/store/adminMaterialSettlement/types';
import { BIconX } from 'bootstrap-vue';
import JsPDF from 'jspdf';
import 'jspdf-autotable';
export default {
  name: 'modal-form',
  data () {
    return {
      fields: [
        { key: 'type', label: 'Tipo', sortable: true, class: 'text-center' },
        { key: 'date', label: 'Fecha', sortable: true, class: 'text-center' },
        { key: 'referral_number', label: 'Número Referencia', sortable: true, class: 'text-center' },
        { key: 'receipt_number', label: 'Número Recibo', sortable: true, class: 'text-center' },
        { key: 'origin_supplier', label: 'Patio Origen / Proveedor', sortable: true, class: 'text-center' },
        { key: 'destiny_customer', label: 'Patio Destino / Cliente', sortable: true, class: 'text-center' },
        { key: 'unit_value', label: 'Valor Unitario', sortable: true, class: 'text-center' },
        { key: 'material_settle_receipt_weight', label: 'Liquidado Con Peso Destino', class: 'text-center' }
      ],
      id: 'admin-material-settlement-modal',
      title: 'Modificar Liquidación de Material',
      textBtnSubmit: 'Guardar',
      consecutive: '',
      date: '',
      third: '',
      subtotalAmount: '',
      subtotalSettlement: '',
      totalSettle: '',
      retentionsPercentage: '',
      retentions: '',
      baseRoyalties: '',
      royalties: '',
      observation: '',
      invoice: '',
      invoiceDate: '',
      internalDocument: '',
      labelTextFieldRequired: 'Campo obligatorio',
      disabledElements: false
    };
  },
  watch: {
    typeAction (val) {
      if (val === 'edit') {
        this.title = 'Modificar Liquidación de Material';
        this.id = 'edit-admin-material-settlement-modal';
        this.textBtnSubmit = 'Guardar cambios';
        this.disabledElements = false;
      }
    },
    adminMaterialSettlement (val) {
      if (this.typeAction === 'edit') {
        this.consecutive = val.consecutive;
        this.date = val.date;
        this.third = val.third;
        this.subtotalAmount = val.subtotalAmount;
        this.subtotalSettlement = val.subtotalSettlement;
        this.totalSettle = val.totalSettle;
        this.baseRoyalties = val.unitRoyalties;
        this.royalties = val.royalties;
        this.retentionsPercentage = val.retentionsPercentage;
        this.retentions = val.retentions;
        this.invoice = val.invoice;
        this.invoiceDate = val.invoiceDate;
        this.internalDocument = val.internalDocument;
        this.observation = val.observation;
      }
    }
  },
  components: {
    BIconX
  },
  computed: {
    ...mapState(types.PATH, [
      'showModalForm',
      'adminMaterialSettlement',
      'typeAction'
    ]),
    items () {
      if (this.adminMaterialSettlement && this.adminMaterialSettlement?.tiquets) {
        return this.adminMaterialSettlement.tiquets.map((item) => {
          return {
            ...item
          };
        });
      } else {
        return [];
      }
    },
    validationCode () {
      return false;
    }
  },
  mounted () {
  },
  methods: {
    ...mapActions(types.PATH, {
      setShowModalForm: types.actions.SET_SHOW_MODAL_FORM,
      edit: types.actions.EDIT
    }),
    resetInfoModal () {
      this.consecutive = '';
      this.date = '';
      this.third = '';
      this.subtotalAmount = '';
      this.subtotalSettlement = '';
      this.totalSettle = '';
      this.retentionsPercentaje = '';
      this.retentions = '';
      this.observation = '';
      this.invoice = '';
      this.invoiceDate = null;
      this.internalDocument = null;
      this.setShowModalForm(false);
    },
    async handleForm (event) {
      event.preventDefault();
      if (this.typeAction === 'edit') {
        await this.edit({
          id: this.adminMaterialSettlement.id,
          invoice: this.invoice,
          invoiceDate: this.invoiceDate,
          internalDocument: this.internalDocument
        });
      }
    },
    upperFormatter (value) {
      return value.toUpperCase();
    },
    generateReport () {
      /* current date */
      const stringFullDate = (new Intl.DateTimeFormat('es-CO', { dateStyle: 'medium', timeStyle: 'short', hour12: false }).format(new Date())).replace(',', '');
      const arrayFullDate = stringFullDate.split(' ');
      let arrayDate = arrayFullDate[0].split('/');
      arrayDate = arrayDate.map(function (x) { return x.padStart(2, '0'); });
      const currentDate = arrayDate[0] + '/' + arrayDate[1] + '/' + arrayDate[2];
      const logo = require('~/assets/images/logo-banner.png');
      const doc = new JsPDF('l', 'in', [11, 8.5]);
      const img = new Image();
      img.src = logo;
      doc.addImage(img, 'png', 0.72, 0.74, 1.15, 0.42);
      doc.setFontSize(10.40);
      doc.setTextColor(68, 114, 196);
      doc.setFont('Helvetica', 'bold');
      doc.text(2.12, 0.95, 'NOVUM ENERGIA COLOMBIA SAS CI');
      doc.setFontSize(6.40);
      doc.text(2.12, 1.10, 'Nit: 900.997.047-9');
      doc.setTextColor(0, 0, 0);
      doc.text(8.65, 1.04, 'Fecha de impresión:');
      doc.text(9.59, 1.04, currentDate);
      doc.text(4.63, 1.29, 'LIQUIDACIÓN DE MATERIAL');
      doc.text(0.7, 1.55, 'TERCERO');
      doc.setFont('Helvetica', 'normal');
      doc.text(1.42, 1.55, this.adminMaterialSettlement.third);
      doc.setFont('Helvetica', 'bold');
      doc.text(4.82, 1.55, 'LIQUIDACION N°');
      doc.setFont('Helvetica', 'normal');
      doc.text(5.81, 1.55, this.adminMaterialSettlement.consecutive);
      doc.setFont('Helvetica', 'bold');
      doc.text(7.3, 1.55, 'FECHA');
      doc.setFont('Helvetica', 'normal');
      doc.text(7.9, 1.55, this.adminMaterialSettlement.date);
      doc.setFont('Helvetica', 'bold');
      doc.text(0.7, 1.8, 'MATERIALES ENTREGADOS ENTRE EL ' + this.adminMaterialSettlement.startDate + ' Y ' + this.adminMaterialSettlement.finalDate);
      const itemsToTable = this.adminMaterialSettlement.tiquets.map((item) => {
        return [item.date, item.referral_number, item.receipt_number, item.license_plate, item.origin_supplier, item.destiny_customer, item.material_name, item.material_weight_settled, item.unit_value, item.material_settlement_net_value];
      });
      itemsToTable.push([{ content: '', colSpan: 10, styles: { cellPadding: 0 } }]);
      itemsToTable.push([{ content: '', colSpan: 6, styles: { cellPadding: 0 } }, { content: 'SUBTOTAL', colSpan: 1, styles: { cellPadding: 0, fontStyle: 'bold', halign: 'left' } }, { content: this.adminMaterialSettlement.subtotalAmount, styles: { cellPadding: 0, halign: 'left' } }, { content: '', styles: { cellPadding: 0, halign: 'left' } }, { content: this.adminMaterialSettlement.subtotalSettlement, styles: { cellPadding: 0, halign: 'left' } }]);
      itemsToTable.push([{ content: '', colSpan: 6, styles: { cellPadding: 0 } }, { content: 'RETENCION EN LA FUENTE', colSpan: 1, styles: { cellPadding: 0, fontStyle: 'bold', halign: 'left' } }, { content: this.adminMaterialSettlement.retentionsPercentage, styles: { cellPadding: 0, halign: 'left' } }, { content: '', styles: { cellPadding: 0, halign: 'left' } }, { content: this.adminMaterialSettlement.retentions, styles: { cellPadding: 0, halign: 'left' } }]);
      itemsToTable.push([{ content: '', colSpan: 6, styles: { cellPadding: 0 } }, { content: 'REGALIAS', colSpan: 1, styles: { cellPadding: 0, fontStyle: 'bold', halign: 'left' } }, { content: this.adminMaterialSettlement.unitRoyalties, styles: { cellPadding: 0, halign: 'left' } }, { content: '', styles: { cellPadding: 0, halign: 'left' } }, { content: this.adminMaterialSettlement.royalties, styles: { cellPadding: 0, halign: 'left' } }]);
      itemsToTable.push([{ content: '', colSpan: 6, styles: { cellPadding: 0 } }, { content: 'TOTAL', colSpan: 1, styles: { cellPadding: 0, fontStyle: 'bold', halign: 'left' } }, { content: '', colSpan: 2, styles: { cellPadding: 0, halign: 'left' } }, { content: this.adminMaterialSettlement.totalSettle, styles: { cellPadding: 0, halign: 'left' } }]);
      itemsToTable.push([{ content: '', colSpan: 10, styles: { cellPadding: 0 } }]);
      itemsToTable.push([{ content: 'OBSERVACIONES', colSpan: 1, styles: { cellPadding: 0, fontStyle: 'bold' } }, { content: this.adminMaterialSettlement.observation, colSpan: 9, styles: { cellPadding: 0 } }]);
      doc.autoTable({
        startX: 1.5,
        startY: 2,
        theme: 'plain',
        bodyStyles: { halign: 'left' },
        styles: { font: 'helvetica', fontSize: 6, cellPadding: 0, overflow: 'linebreak' },
        head: [['Fecha', 'N. Referencia', 'N. Recibo', 'Placa', 'P. Origen / Proveedor', 'P. Destino / Cliente', 'Material', 'Cantidad', 'Valor Unitario', 'Valor Total']],
        body: itemsToTable
      });
      doc.save(this.adminMaterialSettlement.consecutive + ' - ' + this.adminMaterialSettlement.third.replace('/', ' ') + '.pdf');
    }
  }
};
</script>
