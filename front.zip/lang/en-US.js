export default {
  home: 'home',
  material: 'material',
  adminTiquet: 'administrate tiquet',
  tiquet: 'tiquet',
  user: 'user',
  yard: 'yard',
  zone: 'zone',
  rate: 'rate',
  role: 'role ',
  updateProfile: 'update profile',
  freightSettlement: 'freight settlement',
  materialSettlement: 'material settlement',
  adminMaterialSettlement: 'admin material settlement',
  adminFreightSettlement: 'admin freight settlement',
  logout: 'logout',
  synchronize: 'synchronize'
};
