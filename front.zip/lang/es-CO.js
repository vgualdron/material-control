export default {
  home: 'inicio',
  material: 'material',
  adminTiquet: 'administrar tiquete',
  tiquet: 'tiquete',
  user: 'usuario',
  yard: 'patio',
  zone: 'zona',
  rate: 'tarifa',
  role: 'rol',
  updateProfile: 'cambiar contraseña',
  freightSettlement: 'liquidación flete',
  materialSettlement: 'liquidación material',
  adminMaterialSettlement: 'administrar liquidación material',
  adminFreightSettlement: 'administrar liquidación flete',
  logout: 'cerrar sesión',
  synchronize: 'sincronizar'
};
