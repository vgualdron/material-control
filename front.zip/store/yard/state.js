const state = {
  yards: [],
  originYards: [],
  destinyYards: [],
  yard: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
