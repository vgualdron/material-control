const state = {
  dataFromServer: [],
  statusSynchronize: false
};
export default state;
