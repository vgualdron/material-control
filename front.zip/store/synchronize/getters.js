import { typesAuth as types } from './types';
const getters = {
  /* [types.getters.GET_ACTIVE_TOKEN] (state) {
    return state.activeToken;
  } */
};
export default getters;
