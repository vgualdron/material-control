const state = {
  adminTiquets: [],
  adminTiquet: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
