const state = {
  adminMaterialSettlements: [],
  adminMaterialSettlement: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
