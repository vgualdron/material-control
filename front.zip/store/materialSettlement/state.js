const state = {
  materialSettlements: [],
  materialSettlement: null
};
export default state;
