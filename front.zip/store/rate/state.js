const state = {
  rates: [],
  rate: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
