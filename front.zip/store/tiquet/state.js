const state = {
  tiquets: [],
  tiquetsToSynchronize: [],
  tiquet: null,
  showModalForm: false,
  statusTiquet: false,
  typeAction: 'create'
};
export default state;
