// import { typesZone as types } from './types';
const getters = {
};
export default getters;
