const state = {
  adminFreightSettlements: [],
  adminFreightSettlement: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
