const state = {
  users: [],
  user: null,
  showModalForm: false,
  typeAction: 'create'
};
export default state;
