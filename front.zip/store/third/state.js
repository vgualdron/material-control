const state = {
  localeCustomerThirds: [],
  localeSupplierThirds: [],
  localeConveyorThirds: []
};
export default state;
