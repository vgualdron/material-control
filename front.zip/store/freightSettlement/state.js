const state = {
  freightSettlements: [],
  freightSettlement: null
};
export default state;
