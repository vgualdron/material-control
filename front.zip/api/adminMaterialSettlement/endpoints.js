export default {
  primary: 'v1/adminMaterialSettlement'
};
