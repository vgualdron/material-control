export default {
  primary: 'v1/material'
};
