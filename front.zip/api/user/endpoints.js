export default {
  primary: 'v1/user',
  profile: 'changePassword'
};
