export default {
  primary: 'v1/yard'
};
