export default {
  primary: 'v1/rate'
};
