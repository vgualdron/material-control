export default {
  primary: 'v1/zone'
};
