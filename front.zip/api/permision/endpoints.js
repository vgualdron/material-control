export default {
  listBySesion: 'v1/permission/listBySession',
  listBySesionGroup: 'v1/permission/listBySessionGroup',
  listByGroup: 'v1/permission/listByGroup'
};
