export default {
  getTokenActive: 'token/get-active-token',
  login: 'oauth/token',
  primary: 'v1/session'
};
