export default {
  primary: 'v1/synchronize',
  fromServer: 'v1/synchronize/fromServer',
  toServer: 'v1/synchronize/toServer'
};
